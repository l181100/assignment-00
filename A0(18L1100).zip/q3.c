
#include<stdio.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>

int main(int argc, const char*argv[])
{
FILE *fp;
int chk=0,ind=0;
char arr[200] = "\0";
char tmp1[50] = "\0";
char tmp[100];
int spcnt=0,k=0,j=0,n=0,check=0,check_vowel=0,i=0,m=0;

   if(argv[1][0] == 'a')
   {
     fp = fopen("q3_a.txt","r");
   }
   else if(argv[1][0] == 'b')
   {
     fp = fopen("q3_b.txt","r");
   }
   else
   {
    chk=1;
     printf("incorrent input\n");
   }
   
   if(chk==0)
   {
    if (fp == NULL)
    {
        printf("Could not open file\n");
        return 1;
    }
    else
    {
      while (fgets(tmp,sizeof(tmp), fp) != NULL)
      {
        strcat(arr,tmp);
        strcat(arr," ");
      }
      arr[strlen(arr)-2] = '\0';
      printf("\nfull array=  %s", arr);
      fclose(fp);
         
      for (i=0;i<strlen(arr)+1;i++)
      {
        if(arr[i] == ' ')
        spcnt++;
      }
      spcnt++;
      //printf("\nno of spaces = %d",spcnt);
      
      
      
      	for (i=0;i<strlen(arr)+1;i++)
	{
		k=0;
		if(arr[i] == ' ' || arr[i] == '\0')
		{
			for (j=i-1;j>=0;j--)
			{
				if(arr[j] == 'a' || arr[j] == 'e'|| arr[j] == 'i' || arr[j] == 'o' || arr[j] == 'u')
				{
					check_vowel=1;
				}
				if(arr[j] == ' ')
				break;
				tmp[k] = arr[j];
				k++;
				check=1;
			}
			tmp[k] = '\0';
			k++;j++;
		}
		if(check==1 && check_vowel==1)
		{
			for(m= j;tmp[n]!='\0';m++)
			{
				arr[m] = tmp[n];
				n++;
			}
			check=0;
			check_vowel=0;
			n=0;
		}
	}
	printf("\nreversed array  =  %s",arr);
	 
     }
     //writing into another file created at runtime///
     
   FILE *fp;
   fp = fopen("output.txt","a+"); 
   
   fprintf(fp,"%s\n",arr); 
   
     
     
  }
   
 
return 0;
}































