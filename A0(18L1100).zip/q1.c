#include<stdio.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>

int main(int argc, const char*argv[])
{
FILE *fp;
int chk=0,ind=0,cnt=0;
char tmp[100] = "\0";
char arr[200] = "\0";
if(argv[1][0] == 'a')
   {
     fp = fopen("q1_a.txt","r");
   }
   else if(argv[1][0] == 'b')
   {
     fp = fopen("q1_b.txt","r");
   }
   else if(argv[1][0] == 'c')
   {
     fp = fopen("q1_c.txt","r");
   }
   else
   {
    chk=1;
     printf("incorrent input\n");
   }
   if(chk==0)
   {
    if (fp == NULL)
    {
        printf("Could not open file\n");
        return 1;
    }
    else
    {
     while (fgets(tmp,sizeof(tmp), fp) != NULL)
      {
        strcat(arr,tmp);
        strcat(arr," ");
      }
      arr[strlen(arr)-2] = '\0';
      printf("\nfull array=  %s", arr);
      fclose(fp);
      
      for(int i=0;arr[i]!=0;i++)
      {
        if(arr[i]>='0' && arr[i]<='9')
        {
        cnt++;
        }
      }
     printf("\nnumber of digits are : %d",cnt); 
    
    }
   
   
   }
return 0;
}
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
