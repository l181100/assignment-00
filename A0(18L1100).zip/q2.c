
#include<stdio.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>

int main(int argc, const char*argv[])
{

   FILE *fp;
   
   fp = fopen("stud.txt","a+");  
  
  int cnt=0,j=0,k=0,ind=0,i=0;
  char data[200][300];
  
  for(i=0;i<20;i++)
  {
    data[i][0] = '\0';
  }
  
 for(int i=1;argv[i]!=0;i++)
 {
  strcat(data[ind],argv[i]);
  strcat(data[ind]," ");
  //printf("1234 %s" ,data[ind]);
  
  cnt++;
    if(cnt == 3)
    {      
     fprintf(fp,"%s\n",data[ind]);
      data[ind][strlen(data[ind])-1] = '\0';
      ind++;
      cnt=0;
    }
 }
  data[ind][0] = '\0';
 
  fclose(fp);
  
     printf("\ninformation of students : \n");
    for(i=0;i<data[i][0]!=0;i++)
    {
     printf("%s" ,data[i]);
     printf("\n");
    }
  
  
  int num=0;
  printf("\nTo add New Friend press 1\nTo read information of students press 2\nTo delete information of student press 3\nenter your choice\n");
  scanf("%d",&num);
  
  
  
  
  if(num == 1)
  {
    char tmp[30];
    printf("\nEnter name of student\n");
    scanf("%s",tmp);
    strcat(data[ind],tmp);
    strcat(data[ind]," ");
    
    printf("\nEnter rollno of student\n");
    scanf("%s",tmp);
    
    strcat(data[ind],tmp);
    strcat(data[ind]," ");
    
    printf("\nEnter email of student\n");
    scanf("%s",tmp);
    
    strcat(data[ind],tmp);
    strcat(data[ind],"\0");
    
////////////(adding information of new student to file)////////////////
    //fputs(data[ind],fp);
     fp = fopen("stud.txt","a+");  
    fprintf(fp,"%s\n",data[ind]);
      fclose(fp);
    printf("\nafter adding new student : \n");
    for(i=0;i<data[i][0]!=0;i++)
    {
     printf("%s" ,data[i]);
     printf("\n");
    }
    
    
    
 //   ind++;
  }
  

  
  //data[ind][0] = '\0';
  else if(num ==2)
  {
    printf("\nTo read your data press 0\nTo read information of 1st student press 1\nTo read information of 2nd student press 2\nenter your choice\n");
  scanf("%d",&num);
  printf("information of student : %s",data[num]);
  }
  
  
  else if(num ==3)
  {
    printf("\nTo delete your data press 0\nTo delete information of 1st student press 1\nTo delete information of 2nd student press 2\nenter your choice\n");
    scanf("%d",&num);
    for(i=num;data[i][0]!=0;i++)
    {
      strcpy(data[i],data[i+1]);
    }
    printf("\nAfter deletion information of students\n");
    for(i=0;i<data[i][0]!=0;i++)
    {
     printf("%s" ,data[i]);
     printf("\n");
    }
         
    fp = fopen("stud.txt","w"); 
   char a[2] = "";
   fprintf(fp,"%s",a);
    fclose(fp);
    
    fp = fopen("stud.txt","a+");
    for(i=0;i<data[i][0]!=0;i++)
    {
     fprintf(fp,"%s\n",data[i]);
    }
     fclose(fp);
    
    
  }
  else
  {
  printf("\nincorrect input\n");
  }
  
  
 return 0;
}
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
